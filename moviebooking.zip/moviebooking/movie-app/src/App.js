import logo from './logo.svg';
import React from 'react';
import './App.css';
import Controller from './Movie+Booking+App+Frontend+Code/src/screens/Controller';

function App() {
  return (
    <div className="App" id="root">
      <Controller />
    </div>
  );
}

export default App;
